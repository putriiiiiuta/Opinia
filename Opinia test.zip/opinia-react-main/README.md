# Opinia Front End Test
Nama : Mohamad Arizal Hadisucipto
<hr>

Website Ini Dibuat Dengan :
- create-react-app
- Tailwind
<hr>

Demo Link : [Github Pages](https://rzel100.github.io/opinia-react)
Jika Tidak Bisa Coba Lewat Link [Netlify](https://opinia-fe-test.netlify.app/)